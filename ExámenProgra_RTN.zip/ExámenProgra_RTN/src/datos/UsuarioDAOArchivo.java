
package datos;

import entidad.Usuario;

import java.io.*;

import java.util.ArrayList;

import java.util.List;

public class UsuarioDAOArchivo {

    private final String archivo = "usuarios.txt";

    public void guardarUsuario(Usuario usuario) throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivo, true))) {
            bw.write(usuario.toString());
            bw.newLine();
        }
    }

    public List<Usuario> listarUsuarios() throws IOException {
        List<Usuario> usuarios = new ArrayList<>();

        File file = new File(archivo);
        if (!file.exists()) {
            return usuarios;
        }

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 2) {
                    usuarios.add(new Usuario(partes[0], partes[1]));
                }
            }
        }

        return usuarios;
    }
}