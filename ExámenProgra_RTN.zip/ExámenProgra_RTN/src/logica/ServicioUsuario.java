package logica;

import datos.UsuarioDAOArchivo;

import entidad.Usuario;

import java.io.IOException;

import java.util.List;

public class ServicioUsuario {

    private UsuarioDAOArchivo dao = new UsuarioDAOArchivo();

    public void registrarUsuario(String nombre, String correo) throws IOException {

        if (nombre == null || nombre.isBlank()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }

        if (correo == null || !correo.contains("@")) {
            throw new IllegalArgumentException("Correo inválido.");
        }

        Usuario usuario = new Usuario(nombre, correo);
        dao.guardarUsuario(usuario);
    }

    public List<Usuario> obtenerUsuarios() throws IOException {
        return dao.listarUsuarios();
    }
}