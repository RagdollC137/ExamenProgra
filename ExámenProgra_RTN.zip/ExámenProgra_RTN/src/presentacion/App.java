
package presentacion;

import entidad.Usuario;

import logica.ServicioUsuario;

import java.io.IOException;

import java.util.List;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        ServicioUsuario servicio = new ServicioUsuario();

        int opcion;

        do {
            System.out.println("-------- menú --------");
            
            System.out.println("1. Para Registrar usuario");
            
            System.out.println("2. Para Listar usuarios");
            
            System.out.println("3. Para Salir");
            
            System.out.print("Seleccione una opción por favor: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine();

            try {

                switch (opcion) {
                    case 1:
                        System.out.print("Nombre: ");
                        
                        String nombre = scanner.nextLine();

                        System.out.print("Correo: ");
                        
                        String correo = scanner.nextLine();

                        servicio.registrarUsuario(nombre, correo);
                        
                        System.out.println("El Usuario fue registrado correctamente.");
                        break;

                    case 2:
                        List<Usuario> usuarios = servicio.obtenerUsuarios();
                        
                        if (usuarios.isEmpty()) {
                            
                            System.out.println("No hay usuarios registrados.");
                            
                        } else {
                            
                            usuarios.forEach(System.out::println);
                            
                        }
                        break;

                    case 3:
                        System.out.println("Saliendo del sistema");
                        break;

                    default:
                        System.out.println("Opción inválida.");
                }

            } catch (IOException e) {
                
                System.out.println("Error al manejar el archivo: " + e.getMessage());
                
            } catch (IllegalArgumentException e) {
                
                System.out.println("Error de validación: " + e.getMessage());
            }

        } while (opcion != 3);

        scanner.close();
    }
}
